#!/bin/bash

first=true

while true; do

	./cbc racehazard.mps max cuts off Heur off preprocess off threads 8 solve > tmp
	current=$(grep 'Objective value:' tmp | awk -F':' '{ print $2 }' | tr -d ' ')
	if [ "$first" == true ]; then
		initial=$current
		first=false
	fi
	echo "Current objective: $current (initial objective: $initial)"
	if [[ "$current" != "$initial" ]]; then
		echo "Objective value different"
		rm tmp
		break
	fi
done
