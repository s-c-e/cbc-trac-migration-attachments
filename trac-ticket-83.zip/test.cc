#include <coin/CoinModel.hpp>
#include <coin/CbcModel.hpp>
#include <coin/OsiSolverInterface.hpp>

#ifdef COIN_HAS_CLP
#include "coin/OsiClpSolverInterface.hpp"
#endif
#ifdef COIN_HAS_OSL
#include "coin/OsiOslSolverInterface.hpp"
#endif

#include "coin/CbcCutGenerator.hpp"
#include "coin/CbcHeuristicLocal.hpp"
#include "coin/CbcHeuristicGreedy.hpp"
#include "coin/CbcHeuristicFPump.hpp"
#include "coin/CbcHeuristicRINS.hpp"

#include "coin/CglGomory.hpp"
#include "coin/CglProbing.hpp"
#include "coin/CglKnapsackCover.hpp"
#include "coin/CglOddHole.hpp"
#include "coin/CglClique.hpp"
#include "coin/CglFlowCover.hpp"
#include "coin/CglMixedIntegerRounding.hpp"

#include "coin/CbcHeuristic.hpp"

/* 2 * x1 + x2 <= 2
 * x1 - 2 * x2 <= 0
 * x1 >= 0
 * max x1
 */

int main() {

  CoinModel *_prob = new CoinModel();
  OsiSolverInterface *_osi_solver;
  CbcModel *_cbc_model;

  _prob->addColumn(0, 0, 0, -COIN_DBL_MAX, COIN_DBL_MAX, 1.0, 0, false);
  _prob->addColumn(0, 0, 0, 0.0, COIN_DBL_MAX, 0.0, 0, true);
  
  int indexes[2] = {0, 1};

  double row1[2] = {2.0, 1.0};
  _prob->addRow(2, indexes, row1, -COIN_DBL_MAX, 2.0, 0);
  double row2[2] = {1.0, -2.0};
  _prob->addRow(2, indexes, row2, -COIN_DBL_MAX, 0.0, 0);
  
  _prob->setOptimizationDirection(-1.0);
  
  _prob->writeMps("test.mps");

#ifdef COIN_HAS_CLP
  _osi_solver = new OsiClpSolverInterface();
#elif COIN_HAS_OSL
  _osi_solver = new OsiOslSolverInterface();
#else
#error Cannot instantiate Osi solver
#endif

  _osi_solver->loadFromCoinModel(*_prob);

  _cbc_model= new CbcModel(*_osi_solver);

  _osi_solver->messageHandler()->setLogLevel(3);
  _cbc_model->setLogLevel(3);

  _cbc_model->initialSolve();
  //  _cbc_model->solver()->setHintParam(OsiDoReducePrint, true, OsiHintTry);

  if (!_cbc_model->isInitialSolveAbandoned() &&
      _cbc_model->isInitialSolveProvenOptimal() &&
      !_cbc_model->isInitialSolveProvenPrimalInfeasible() &&
      !_cbc_model->isInitialSolveProvenDualInfeasible()) {

//     CglProbing generator1;
//     generator1.setUsingObjective(true);
//     generator1.setMaxPass(3);
//     generator1.setMaxProbe(100);
//     generator1.setMaxLook(50);
//     generator1.setRowCuts(3);
//     _cbc_model->addCutGenerator(&generator1, -1, "Probing");

//     CglGomory generator2;
//     generator2.setLimit(300);
//     _cbc_model->addCutGenerator(&generator2, -1, "Gomory");

//     CglKnapsackCover generator3;
//     _cbc_model->addCutGenerator(&generator3, -1, "Knapsack");

//     CglOddHole generator4;
//     generator4.setMinimumViolation(0.005);
//     generator4.setMinimumViolationPer(0.00002);
//     generator4.setMaximumEntries(200);
//     _cbc_model->addCutGenerator(&generator4, -1, "OddHole");

//     CglClique generator5;
//     generator5.setStarCliqueReport(false);
//     generator5.setRowCliqueReport(false);
//     _cbc_model->addCutGenerator(&generator5, -1, "Clique");

//     CglMixedIntegerRounding mixedGen;
//     _cbc_model->addCutGenerator(&mixedGen, -1, "MixedIntegerRounding");

//     CglFlowCover flowGen;
//     _cbc_model->addCutGenerator(&flowGen, -1, "FlowCover");

// #ifdef COIN_HAS_CLP
//     OsiClpSolverInterface* osiclp =
//       dynamic_cast<OsiClpSolverInterface*>(_cbc_model->solver());
//     if (osiclp->getNumRows() < 300 && osiclp->getNumCols() < 500) {
//       osiclp->setupForRepeatedUse(2, 0);
//     }
// #endif

//     CbcRounding heuristic1(*_cbc_model);
//     heuristic1.setWhen(3);
//     _cbc_model->addHeuristic(&heuristic1);

//     CbcHeuristicLocal heuristic2(*_cbc_model);
//     heuristic2.setWhen(3);
//     _cbc_model->addHeuristic(&heuristic2);

//     CbcHeuristicGreedyCover heuristic3(*_cbc_model);
//     heuristic3.setAlgorithm(11);
//     heuristic3.setWhen(3);
//     _cbc_model->addHeuristic(&heuristic3);

//     CbcHeuristicFPump heuristic4(*_cbc_model);
//     heuristic4.setWhen(3);
//     _cbc_model->addHeuristic(&heuristic4);

//     CbcHeuristicRINS heuristic5(*_cbc_model);
//     heuristic5.setWhen(3);
//     _cbc_model->addHeuristic(&heuristic5);

//     if (_cbc_model->getNumCols() < 500) {
//       _cbc_model->setMaximumCutPassesAtRoot(-100);
//     } else if (_cbc_model->getNumCols() < 5000) {
//       _cbc_model->setMaximumCutPassesAtRoot(100);
//     } else {
//       _cbc_model->setMaximumCutPassesAtRoot(20);
//     }

//     if (_cbc_model->getNumCols() < 5000) {
//       _cbc_model->setNumberStrong(10);
//     }

//     _cbc_model->solver()->setIntParam(OsiMaxNumIterationHotStart, 100);
    _cbc_model->branchAndBound();
  }

  std::cerr << "Objective value : " 
	    << _cbc_model->getObjValue() << std::endl;
  return 0;
}
