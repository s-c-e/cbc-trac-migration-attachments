// PfofModelv1.cpp : Defines the exported functions for the DLL application.
//
#include "stdio.h"

#include "stdafx.h"
#include "PfofModel.h"

// For defining the problem with matrices
#include "CoinPackedMatrix.hpp"
#include "CoinPackedVector.hpp"

// For Branch and bound
#include "CbcModel.hpp"
#include "CbcStrategy.hpp"
#include "OsiClpSolverInterface.hpp"

#include "OsiCbcSolverInterface.hpp"

#include "CoinError.hpp"
#include "CoinFinite.hpp"

// For SOS2
#include "CbcBranchActual.hpp"

using namespace std;


// Returns true if the solution is feasible, false o/w
bool __stdcall PfofModel_OptimizeSimple(
										int totalSize, 
										int numSets, 
										int numBreakpoints,
										int * tradeMechanisms,
										int * sizes,
										double * revenues,
										bool shouldLog,
										double stopTimeMilliseconds,
										int * solutionTradeMechanism,
										int * solutionSize
										)
{
	double objective = 0;
	return PfofModel_OptimizeMaxParticipation(totalSize, numSets, numBreakpoints, tradeMechanisms,
		sizes, revenues, shouldLog, stopTimeMilliseconds, solutionTradeMechanism, solutionSize, 
		-1, revenues, objective);
}

// Returns true if the solution is feasible, false o/w
bool __stdcall PfofModel_OptimizeMaxParticipation(
										int totalSize, 
										int numSets, 
										int numBreakpoints,
										int * tradeMechanisms,
										int * sizes,
										double * revenues,
										bool shouldLog,
										double stopTimeMilliseconds,
										int * solutionTradeMechanism,
										int * solutionSize,
										double maxParticipation,
										double * participations,
										double objective
										)
{

	FILE *ofp;
	ofp = fopen("C:\\Documents and Settings\\ylee\\My Documents\\Visual Studio 2008\\Projects\\PfofModel\\ReadAndSolve\\runs\\CBCsol.txt", "w");
	
	// Create input for optimization model
	int numRows = numSets + 1;
	if (maxParticipation >= 0)
	{
		numRows++;
	}
	double * obj     = new double[numBreakpoints];
	double * collb   = new double[numBreakpoints];
	double * colub   = new double[numBreakpoints];
	double * rowlb   = new double[numRows];
	double * rowub   = new double[numRows];
	double * weights = new double[numBreakpoints];
	int * indices    = new int[numBreakpoints];
	int * setIndices = new int[numSets+1];
	int * setTypes   = new int[numSets];

	CoinPackedMatrix * matrix = new CoinPackedMatrix(false, 0, 0);
	matrix->setDimensions(0, numBreakpoints);

	OsiClpSolverInterface solver;
	int logLevel = 0;
	if (shouldLog)
	{
		logLevel = 3; //4
	}	
	solver.setLogLevel(logLevel);

	// Fill in input vectors
	for (int pointIdx=0; pointIdx<numBreakpoints; pointIdx++)
	{
	  indices[pointIdx] = pointIdx;
	  weights[pointIdx] = (double) sizes[pointIdx];
	  //weights[pointIdx] = (double) sizes[pointIdx] + 1;  //for 0 size, can't have a 0 weight so add 1
	  obj[pointIdx] = revenues[pointIdx];
	  collb[pointIdx] = 0.0;
	  colub[pointIdx] = solver.getInfinity();
	}

	
	// Fill in row bounds:  Sets definition constraints 
	for (int rowIdx=0; rowIdx<numSets; rowIdx++)
	{
		rowlb[rowIdx] = 1;
		rowub[rowIdx] = 1;
	}

	// Fill in row bounds:  total size constraint
	rowlb[numSets] = totalSize;
	rowub[numSets] = totalSize;

	// Fill in row bounds:  max participation constraint
	if (maxParticipation >= 0)
	{
		rowlb[numSets+1] = 0;
		rowub[numSets+1] = maxParticipation;
	}

	
	// Determine set idx 
	int currentTradeMechanism = -1;
	int currentTradeMechanismNumber = 0;
	for (int idx=0; idx<=numBreakpoints; idx++)
	{
		if (currentTradeMechanism != tradeMechanisms[idx])
		{
			setIndices[currentTradeMechanismNumber] = idx;
			currentTradeMechanismNumber++;
			currentTradeMechanism = tradeMechanisms[idx];
		}
	}
	setIndices[numSets] = numBreakpoints;  // last one to help calc later


	// Fill in set type (SOS Type 2)
	for (int i=0; i<numSets; i++)
	{
		setTypes[i] = 2;
	}


	// Add rows to matrix:  Sets definition constraints
	for (int setIdx=0; setIdx<numSets; setIdx++)
	{
		CoinPackedVector row;
		for (int setItem=setIndices[setIdx]; setItem<setIndices[setIdx+1]; setItem++)
		{
			row.insert(setItem, 1);
		}
		matrix->appendRow(row);
	}

	// Add rows to matrix:  total size constraint
	CoinPackedVector rowTotalSize;
	for (int pointIdx=0; pointIdx<numBreakpoints; pointIdx++)
	{
		rowTotalSize.insert(pointIdx, sizes[pointIdx]);
	}
	matrix->appendRow(rowTotalSize);

	// Add rows to matrix:  max participation constraint
	if (maxParticipation >= 0)
	{
		CoinPackedVector rowMaxParticipation;
		for (int pointIdx=0; pointIdx<numBreakpoints; pointIdx++)
		{
			rowMaxParticipation.insert(pointIdx, participations[pointIdx]);
		}
		matrix->appendRow(rowMaxParticipation);
	}

	// Load lp problem and sos2 constraints
	solver.loadProblem(*matrix, collb, colub, obj, rowlb, rowub);
	//solver.setSOSData(numSets, setTypes, setIndices, indices, weights);

	OsiSolverInterface * solver1 = &solver;
	CbcModel model(*solver1);

	// Create SOS2 sets and set SOS priorities high
	int * priority = new int[numSets];
	CoinFillN(priority,numSets,1);
	CbcObject **objects = new CbcObject * [numSets];
		
	currentTradeMechanism = -1;
	currentTradeMechanismNumber = 0;
	int * nMember = new int[numSets];
	int countMember = 0;
	for ( int idx=0; idx<=numBreakpoints; idx++)
	{
		if (currentTradeMechanism != tradeMechanisms[idx]){
			if( currentTradeMechanismNumber != 0 ){
				nMember[currentTradeMechanismNumber-1] = countMember;
				std::cout<< nMember[currentTradeMechanismNumber-1] << endl;
			}
			countMember = 0;
			currentTradeMechanismNumber += 1;
			currentTradeMechanism = tradeMechanisms[idx];
		}
		countMember++;
	}

	for( int SOS2=0; SOS2<numSets; SOS2++ ){
		std::cout<< nMember[SOS2] << endl;
		int * memberIndices = new int[nMember[SOS2]];

		for( int i = 0; i < nMember[SOS2]; i++ ){
			memberIndices[i] = setIndices[SOS2] + i ;
			std::cout<< memberIndices[i] << endl;
		}
		objects[SOS2] = new CbcSOS( &model, nMember[SOS2], memberIndices, NULL, SOS2, 2 );
	}
	model.addObjects( numSets, objects );
	for( int i = 0 ;i<numSets; ++i){
		delete objects[i];
	}
	delete [] objects;
	model.passInPriorities(priority,true);
	delete [] priority;


	// Stop after time 
	model.setDblParam(CbcModel::CbcMaximumSeconds,stopTimeMilliseconds/1000.0);
	//model.setMaximumSeconds(stopTimeMilliseconds/1000.0);

	// Gap
	//model.setAllowablePercentageGap( 10 );


	// Set precision parameters
/*	solver1->setDblParam( OsiDblParam::OsiDualObjectiveLimit, 0.000001 );
	solver1->setDblParam( OsiDblParam::OsiPrimalObjectiveLimit, 0.000001 );
	solver1->setDblParam( OsiDblParam::OsiPrimalTolerance, 0.000001 );
	solver1->setDblParam( OsiDblParam::OsiDualTolerance, 0.000001 );	
*/	
	// Set strategy - below is == CbcStrategyDefault()
	//CbcStrategyDefault strategy(true,5,0);
	//model.setStrategy(strategy);

	// Logging
	model.solver()->messageHandler()->setLogLevel(logLevel);
	model.messageHandler()->setLogLevel(logLevel);

	// Maximization problem
	model.setObjSense(-1.0);


	// Do complete search
	model.branchAndBound();
	

	fprintf( ofp , "sos2 isProvenOptimal: %f \n", model.isProvenOptimal() );
	fprintf( ofp , "isProvenInfeasible: %f \n", model.isProvenInfeasible() );
	fprintf( ofp , "current milli Seconds: %f \n", model.getCurrentSeconds()* 1000 );
	fprintf( ofp , "is time limit reached: %f \n", model.isSolutionLimitReached() );
	fprintf( ofp , "secondary status: %f \n", model.secondaryStatus() );

	std::cout<<"sos2 isProvenOptimal: " << model.isProvenOptimal() << endl;
	std::cout<<"isProvenInfeasible: " << model.isProvenInfeasible() << endl;
	std::cout<<"current milli Seconds: " << model.getCurrentSeconds()* 1000 << endl;
	std::cout<<"is time limit reached: " << model.isSolutionLimitReached() << endl;
	std::cout<<"secondary status: " << model.secondaryStatus() << endl;


	// Get solution
	double * solutionDouble = model.currentSolution();
	double optimalValue = model.getCurrentObjValue(); 
	bool isSecondsLimitReached = model.isSecondsLimitReached();


	// Check if feasible and convert solution 
	bool isFeasibleSolution = true;	

	if (model.isProvenInfeasible())
	{
		isFeasibleSolution = false;
	}
	else if (solutionDouble == NULL)
	{
		isFeasibleSolution = false;
	}
	else if (!model.isProvenOptimal())
	{
		for (int setIdx=0; setIdx<numSets; setIdx++)
		{
			int firstPositive = -1;
			int secondPositive = -1;
			double setSolution = 0;
			for (int idx=setIndices[setIdx]; idx<setIndices[setIdx+1]; idx++)
			{
				if (solutionDouble[idx] > fabs(1.0e-7) && firstPositive==-1)
				{
					firstPositive = idx;
					setSolution += solutionDouble[idx];
				}
				else if (solutionDouble[idx] > fabs(1.0e-7))
				{
					secondPositive = idx;
					setSolution += solutionDouble[idx];
					break;
				}
			}
			// check to make sure they add to one and are adjacent
			if (fabs(setSolution - 1.0)>1.0e-7)
			{
				isFeasibleSolution = false;
				break;
			}
			if (secondPositive > 0 && abs(firstPositive - secondPositive) > 1)
			{
				isFeasibleSolution = false;
				break;
			}
		}
	}

	// Translate Solution
	if (isFeasibleSolution)
	{
		for (int setIdx=0; setIdx<numSets; setIdx++)
		{
			int tradeMechanism = tradeMechanisms[setIndices[setIdx]];
			double sizeDouble = 0;
			for (int idx=setIndices[setIdx]; idx<setIndices[setIdx+1]; idx++)
			{
				if (solutionDouble[idx] > fabs(1.0e-7))
				{
					sizeDouble += solutionDouble[idx] * sizes[idx];
				}
			}
			// round nearest int
			int size = (int)floor(sizeDouble + 0.5);   
			solutionTradeMechanism[setIdx] = tradeMechanism;
			solutionSize[setIdx] = size;
		}
	}

	// Record objective value
	objective = optimalValue;
	//cout<< "CBC obj: " << objective << endl;

	// Output solution
	//if( isFeasibleSolution == true ){

		fprintf( ofp , "CBC obj: %f \n", optimalValue );
		for( int i=0; i<numBreakpoints; ++i ){
			fprintf( ofp, "%f \n", solutionDouble[i] );
		}
		fprintf( ofp , "solutionSize: \n");
		for( int i=0; i<numBreakpoints; ++i ){
			fprintf( ofp, "%f \n", solutionSize[i] );
		}
		fprintf( ofp , "solutionTradeMechanism: \n");
		for( int i=0; i<numBreakpoints; ++i ){
			fprintf( ofp, "%f \n", solutionTradeMechanism[i] );
		}
		fclose(ofp);
		
	//} 


	delete matrix;
	delete [] obj;
	delete [] collb;
	delete [] colub;
	delete [] rowlb;
	delete [] rowub;
	delete [] indices;
	delete [] weights;
	delete [] setTypes;
	delete [] setIndices;

	return isFeasibleSolution;

	
}


bool __stdcall PfofModel_MIP(
								int totalSize, 
								int numSets, 
								int numBreakpoints,
								int * tradeMechanisms,
								int * sizes,
								double * revenues,
								bool shouldLog,
								double stopTimeMilliseconds,
								int * solutionTradeMechanism,
								int * solutionSize,
								double maxParticipation,
								double * participations,
								double objective
								)
{
	// Create a problem pointer.  We use the base class here.
   //OsiSolverInterface *si;
	OsiClpSolverInterface si;

	std::cout<<"1"<<endl;

   // When we instantiate the object, we need a specific derived class.
   //si = new OsiClpSolverInterface;
   //   si = new OsiGlpkSolverInterface;  

   // Read in an mps file.  This one's from the MIPLIB library.
	si.readLp( "C:\\Documents and Settings\\ylee\\My Documents\\Visual Studio 2008\\Projects\\PfofModel\\ReadAndSolve\\runs\\minMIPModel.lp" );
   //si.readLp("MIPModel.lp");
   std::cout<<"2"<<endl;
	   //readMps("MIPinput");
  // si.setObjSense(-1); // maximizing
   si.writeLp( "IsModelCorrect.lp");

	OsiSolverInterface * si1 = &si;
	CbcModel model(*si1);

	model.setDblParam(CbcModel::CbcMaximumSeconds,stopTimeMilliseconds/1000.0);
	

   // Solve the (relaxation of the) problem
   //si.initialSolve();
   model.branchAndBound();

   std::cout<<"mip isProvenOptimal: " << model.isProvenOptimal() << endl;
   std::cout<<"isProvenInfeasible: " << model.isProvenInfeasible() << endl;
   std::cout<<"current milli Seconds: " << model.getCurrentSeconds()* 1000 << endl;
   std::cout<<"is time limit reached: " << model.isSolutionLimitReached() << endl;
   std::cout<<"secondary status: " << model.secondaryStatus() << endl;
   

   // Check the solution
   if ( model.isProvenOptimal() == true ) { 
      std::cout << "Found optimal solution!" << std::endl; 
      std::cout << "Objective value is " << si.getObjValue() << std::endl;

      int n = si.getNumCols();
      const double *solution;
      solution = si.getColSolution();
      // We could then print the solution or examine it.
   } else {
      std::cout << "Didn't find optimal solution." << std::endl;
      // Could then check other status functions.
   }

   return true;


/*	cout<<"inside"<<endl;
	 // Create a problem pointer.  We use the base class here.
   //OsiSolverInterface *si;
	OsiClpSolverInterface si;

   cout<<"1"<<endl;

   // When we instantiate the object, we need a specific derived class.
   //si = new OsiClpSolverInterface;
   //   si = new OsiGlpkSolverInterface;  

   // Read in an mps file.  This one's from the MIPLIB library.
   si.readLp("MIPModel.lp");
   cout<<"2"<<endl;
	   //readMps("MIPinput");

   // Solve the (relaxation of the) problem
   si.initialSolve();

   // Check the solution
   if ( si.isProvenOptimal() ) { 
      std::cout << "Found optimal solution!" << std::endl; 
      std::cout << "Objective value is " << si.getObjValue() << std::endl;

      int n = si.getNumCols();
      const double *solution;
      solution = si.getColSolution();
      // We could then print the solution or examine it.
   } else {
      std::cout << "Didn't find optimal solution." << std::endl;
      // Could then check other status functions.
   }

/*
	// Specify the problem matrix sizes
	int n_cols =  2*( numBreakpoints - numSets ); //Y's and Z's
	//std::cout<< "n_cols: " << n_cols << endl;
	int n_rows = 2+ 2*(numBreakpoints-numSets); //+ (numBreakpoints-numSets-1); 
		// sizeConstraint + weightConstraint + binaryConstraint1_left + binaryConstraint1_right + binaryConstraint2_left
	//std::cout<< "n_rows: " << n_rows << endl;
	
	// Set containers
	double *obj       = new double[n_cols]; //the objective coefficients
	double *col_lb    = new double[n_cols]; //the column lower bounds
	double *col_ub    = new double[n_cols]; //the column upper bounds
	double *row_lb    = new double[n_rows]; //the row lower bounds
	double *row_ub    = new double[n_rows]; //the row lower bounds
	
	// Set index mapping
	int *yVarIndex = new int;
	int *zVarIndex = new int;

	//Define the const lowraint matrix
	CoinPackedMatrix matrix;
	matrix.setDimensions(0, n_cols);
	//CoinPackedMatrix *matrix =  new CoinPackedMatrix(false,0,0);
	//matrix->setDimensions(0, n_cols);
	//cout<<"1"<<endl;
	
	
	// Create a problem pointer.
	//OsiCbcSolverInterface *si;
	OsiClpSolverInterface si;
	//cout<<"si"<<endl;
	
	// When we instantiate the object, we need a specific derived class.
	//si = new OsiCbcSolverInterface;  
	
	CoinIotaN( yVarIndex, numBreakpoints - numSets, 0 ); // there are {numBreakpoints-numSets) many Y's, whose indices start from 0
	CoinIotaN( zVarIndex, numBreakpoints - numSets, numBreakpoints - numSets ); // there are {numBreakpoints-numSets) many Z's, whose indices start from {numBreakpoints-numSets)
	
	//cout<<"here1"<<endl;
	
	//Compute parameters
	int *intervals     = new int[numBreakpoints - numSets]; 
	double *fSlope     = new double[numBreakpoints - numSets];
	double *fIntercept = new double[numBreakpoints - numSets];
	double *gSlope     = new double[numBreakpoints - numSets];
	double *gIntercept = new double[numBreakpoints - numSets];
	int largeNumber = 0;
	
	//cout<<"here2"<<endl;
	int count = 0;
	for( int i = 0; i<numBreakpoints; ++i ){
		// if whenever a new set starts
		if( i == 0 || tradeMechanisms[i-1] != tradeMechanisms[i] ){
			continue;
		}
		else{
			//cout<< count << endl;
			intervals[count] = sizes[i] - sizes[i-1];
			//cout<< "intervals: " << intervals[count] << endl;
			if( intervals[count] > largeNumber ){
				largeNumber = intervals[count];
			}
			count++;
		}
	}

	count = 0;
	for( int i = 0; i < numBreakpoints; ++i ){
		// if whenever a new set starts
		if( i == 0 || tradeMechanisms[i-1] != tradeMechanisms[i] ){
			continue;
		}
		else{
			fSlope[count] = (double) (revenues[i] - revenues[i-1])/(sizes[i] - sizes[i-1] ) ;
			fIntercept[count] = (double) -fSlope[count]*sizes[i-1] + revenues[i-1];
			//cout<<"participations:" << participations[i] << endl;
			gSlope[count] = (double) (participations[i] - participations[i-1] )/(sizes[i] - sizes[i-1] );
			gIntercept[count] = (double) -gSlope[count]*sizes[i-1] + participations[i-1];
			count++;
		}
	}


	
	//Define the variable lower/upper bounds and types
	for( int i = 0; i < n_cols; ++i ){
		// Y's
		if( i < n_cols/2){
			col_lb[i] = 0;
			col_ub[i] = totalSize;
			//si->setContinuous(i);
		}
		// Z's
		else{
			col_lb[i] = 0;
			col_ub[i] = 1;
			//si->setInteger(i);
		}
	}
	
	
	

	
	//Construct constraints by appending rows
	// #0: size constraint
	CoinPackedVector sizeConstraint;
	for( int i = 0; i< n_cols; i++){
		if( i < n_cols/2 ){ //Y's
			sizeConstraint.insert(i,1.0); // coefficients for Y's are 1
		}
	}
	row_lb[0] = totalSize;
	row_ub[0] = totalSize;
	matrix.appendRow( sizeConstraint );
	cout<<"2"<<endl;

	// #1: weight constraint
	CoinPackedVector weightConstraint;
	for( int i = 0; i< n_cols; i++){
		if( i < n_cols/2 ){ //Y's
			weightConstraint.insert(i,gSlope[i]); // coefficients for Y's are gSlope
		}
	}
	cout<<"3"<<endl;
	double gInterceptSum = 0;
	count = 0;
	for( unsigned int i = 0; i!= numBreakpoints; ++i){
		// if whenever a new set starts
		if( i == 0 || tradeMechanisms[i-1] != tradeMechanisms[i] ){
			gInterceptSum += gIntercept[count];
		}
		// if whenever not the first element of a set
		if( i != 0 ){
			if( tradeMechanisms[i-1] == tradeMechanisms[i] ){
				count ++;
			}
		}
	}
	row_lb[1] = -1.0 * si.getInfinity();
	row_ub[1] = maxParticipation - gInterceptSum;
	matrix.appendRow(weightConstraint);
	cout<<"4"<<endl;

	// #2~#(2+numBreakpoints-numSets)
	// largeNumber * z_k >= intervals_k - y_k
	for( int r = 2; r < 2 + numBreakpoints - numSets + 1; ++r ){
		cout<<" row " << r << endl;
		CoinPackedVector bin1Left;
		for( int i = 0; i< n_cols; i++){
			if( i < n_cols/2 ){ //Y's
				if( r-2 == i ){
					bin1Left.insert(i, 1.0);
				}
			}
			else{ //Z's
				if( r-2 == i - n_cols/2){
					bin1Left.insert(i,largeNumber);
				}
			}
		}
		row_lb[r] = intervals[r-2];
		row_ub[r] = si.getInfinity();
		matrix.appendRow( bin1Left );
	}
	cout<<"5"<<endl;

	

	// #(2+numBreakpoints-numSets+1)~ #(2+2*(numBreakpoints-numSets))
	// intervals_k - y_k >= 0
	for( int r = 2+numBreakpoints-numSets+1; r < 2+2*(numBreakpoints-numSets)+1; ++r ){
		cout<<" row " << r << endl;
		CoinPackedVector bin1Right;
		for( int i = 0; i< n_cols; i++){
			if( i < n_cols/2 ){ //Y's
				if( r-(2+numBreakpoints-numSets+1) == i ){
					bin1Right.insert(i, -1);
				}
			}
			
		}
		row_lb[r] = -1.0 * intervals[r-(2+numBreakpoints-numSets+1)];
		row_ub[r] = si.getInfinity();
		matrix.appendRow( bin1Right );
	}
	
	cout<<"6"<<endl;
	

/*	// #(2+2*(numBreakpoints-numSets)+1)~ #(2+3*(numBreakpoints-numSets)-1)
	// largeNumber * ( 1-z_k ) >= y_{k+1}
	for( int r = 2+2*(numBreakpoints-numSets)+1; r < 2+3*(numBreakpoints-numSets); ++r ){
		cout<<" row " << r << endl;
		CoinPackedVector bin2Left;
		for( int i = 0; i< n_cols-1; i++){
			if( i < n_cols/2 ){ //Y's
				if( r-(2+2*(numBreakpoints-numSets)+1) == i ){
					cout<<" 1 * var_" << i+1 << endl;
					bin2Left.insert(i+1, 1);
				}
			}
			if( i>= n_cols/2){ //Z's
				if( r-(2+2*(numBreakpoints-numSets)+1) == i - n_cols/2 ){
					cout<< " largeNumber * var_" << i << endl;
					bin2Left.insert(i, largeNumber);
				}
			}
		}
		
		row_lb[r] = 0;
		cout<<"after lb" << endl;
		row_ub[r] = largeNumber;
		cout<<"after ub" << endl;
		matrix->appendRow( bin2Left );
		cout<<"append a row"<<endl;
		
	}
	cout<<"7"<<endl;
	

*/
	
/*	//Load the problem to OSI
	si.loadProblem( matrix, col_lb, col_ub, obj, row_lb, row_ub);

	cout<<"9.5"<<endl;

	//OsiSolverInterface * solver1 = &si;
	//CbcModel model(*solver1);
	CbcModel model( si );



	cout<<"10"<<endl;
	

	//Define the objective coefficients.
	si.setObjSense(-1); // maximizing
	for( int i = 0; i< n_cols; i++){
		if( i < n_cols/2 ){ //Y's
			obj[i] = fSlope[i];
		}
		else{ //Z's
			obj[i] = fSlope[i];
		}
	}
	double objConstantTerm = 0;
	count = 0;
	for( unsigned int i = 0; i!= numBreakpoints; ++i){
		// if whenever a new set starts
		if( i == 0 || tradeMechanisms[i-1] != tradeMechanisms[i] ){
			objConstantTerm += fIntercept[count];
		}
		// if whenever not the first element of a set
		if( i != 0 ){
			if( tradeMechanisms[i-1] == tradeMechanisms[i] ){
				count ++;
			}
		}
	}
	cout<<"8"<<endl;

	//si->setInteger( zVarIndex, numBreakpoints - numSets);
	si.setContinuous( yVarIndex, numBreakpoints - numSets);

	cout<<"9"<<endl;

	// Write the MPS file to a file called example.mps

	//si.writeMpsNative( "MIP.mps", NULL, NULL);
	//cout<<"9.9"<<endl;
	
	
	
	// Solve branch-and-bound
	si.branchAndBound();
	//model.branchAndBound();
	cout<<"11"<<endl;
	
	// Check the solution
	if ( si.isProvenOptimal() ) { 
		std::cout << "Found optimal solution!" << std::endl; 
		std::cout << "Objective value is " << si.getObjValue() << std::endl;
		
		int n = si.getNumCols();
		const double *solution;
		solution = si.getColSolution();
		// We could then print the solution or examine it.
	} 
	else {
		std::cout << "Didn't find optimal solution." << std::endl;
		// Could then check other status functions.
	}

	*/
	return true;


}